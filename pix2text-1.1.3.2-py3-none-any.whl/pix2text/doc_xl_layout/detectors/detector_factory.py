# coding: utf-8

from .ctdet_subfield import CtdetDetector_Subfield

detector_factory = {
    'ctdet_subfield': CtdetDetector_Subfield
}
