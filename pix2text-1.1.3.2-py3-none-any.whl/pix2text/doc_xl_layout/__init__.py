# coding: utf-8
# This whole directory is adapted from https://github.com/AlibabaResearch/AdvancedLiterateMachinery.
# Thanks to the authors.
from .doc_xl_layout_parser import DocXLayoutParser