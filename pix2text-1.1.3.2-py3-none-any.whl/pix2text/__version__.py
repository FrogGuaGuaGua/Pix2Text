# coding: utf-8
# [Pix2Text](https://github.com/breezedeus/pix2text): an Open-Source Alternative to Mathpix.
# Copyright (C) 2022-2025, [Breezedeus](https://www.breezedeus.com).

__version__ = '1.1.3.2'
