# coding: utf-8
from .layoutlmv3_layout_parser import LayoutLMv3LayoutParser
