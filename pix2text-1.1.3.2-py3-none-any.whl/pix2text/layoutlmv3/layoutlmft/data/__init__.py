# flake8: noqa
from .data_collator import DataCollatorForKeyValueExtraction
